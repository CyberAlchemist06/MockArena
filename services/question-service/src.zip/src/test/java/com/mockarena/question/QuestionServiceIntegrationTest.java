package com.mockarena.question;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mockarena.question.domain.QuestionVersionRepository;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.test.web.servlet.MockMvc;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import java.util.UUID;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.reset;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@Testcontainers
@Transactional
class QuestionServiceIntegrationTest {
    @Container static final PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:16-alpine");
    @DynamicPropertySource static void database(DynamicPropertyRegistry r) {
        r.add("spring.datasource.url", postgres::getJdbcUrl); r.add("spring.datasource.username", postgres::getUsername); r.add("spring.datasource.password", postgres::getPassword);
    }
    @Autowired MockMvc mvc; @Autowired ObjectMapper json; @Autowired JdbcTemplate jdbc; @Autowired EntityManager entityManager;
    @MockitoSpyBean QuestionVersionRepository questionVersionRepository;
    @AfterEach void resetRepositorySpy() { reset(questionVersionRepository); }

    @Test void createsQuestionAndInitialVersionAtomically_andNeverReturnsHiddenTests() throws Exception {
        String body=validRequest(UUID.randomUUID());
        String response=mvc.perform(post("/api/v1/questions").contentType(MediaType.APPLICATION_JSON).content(body))
            .andExpect(status().isCreated())
            .andExpect(header().string("Location", org.hamcrest.Matchers.matchesPattern("/api/v1/questions/[0-9a-f-]+/versions/1")))
            .andExpect(jsonPath("$.questionId").exists())
            .andExpect(jsonPath("$.versionNumber").value(1))
            .andExpect(jsonPath("$.status").value("DRAFT"))
            .andExpect(jsonPath("$.title").value("Two Sum"))
            .andExpect(jsonPath("$.hiddenTests").doesNotExist())
            .andReturn().getResponse().getContentAsString();
        assertThatThrownBy(() -> json.readTree(response).required("hiddenTests")).isInstanceOf(IllegalArgumentException.class);
        String questionId=json.readTree(response).required("questionId").asText();
        entityManager.flush();
        Integer questionCount=jdbc.queryForObject("select count(*) from question.questions where id = ?", Integer.class, UUID.fromString(questionId));
        Integer versionCount=jdbc.queryForObject("select count(*) from question.question_versions where question_id = ? and version_number = 1", Integer.class, UUID.fromString(questionId));
        org.assertj.core.api.Assertions.assertThat(questionCount).isEqualTo(1);
        org.assertj.core.api.Assertions.assertThat(versionCount).isEqualTo(1);
        mvc.perform(post("/api/v1/questions/{id}/versions/1/publish",questionId).contentType(MediaType.APPLICATION_JSON).content("{\"expectedQuestionVersion\":0,\"expectedVersion\":0}"))
            .andExpect(status().isOk()).andExpect(jsonPath("$.hiddenTests").doesNotExist());
        assertThatThrownBy(() -> jdbc.update("update question.question_versions set title = 'changed' where question_id = ? and version_number = 1", UUID.fromString(questionId)))
            .hasMessageContaining("published question versions are immutable");
    }

    @Test void rejectsBlankTitleUsingStableValidationError() throws Exception {
        String body=validRequest(UUID.randomUUID()).replace("\"title\":\"Two Sum\"", "\"title\":\"   \"");
        assertValidationFailure(body);
    }

    @Test void rollsBackQuestionWhenInitialVersionPersistenceFails() throws Exception {
        doThrow(new IllegalStateException("Version persistence failed")).when(questionVersionRepository).save(any());
        mvc.perform(post("/api/v1/questions").contentType(MediaType.APPLICATION_JSON).content(validRequest(UUID.randomUUID())))
            .andExpect(status().isConflict())
            .andExpect(jsonPath("$.code").value("INVALID_STATE"));
        Integer questionCount=jdbc.queryForObject("select count(*) from question.questions", Integer.class);
        Integer versionCount=jdbc.queryForObject("select count(*) from question.question_versions", Integer.class);
        org.assertj.core.api.Assertions.assertThat(questionCount).isZero();
        org.assertj.core.api.Assertions.assertThat(versionCount).isZero();
    }

    @Test void rejectsMissingRequiredNestedContentUsingStableValidationError() throws Exception {
        String body=validRequest(UUID.randomUUID()).replace("\"examples\":[],", "");
        assertValidationFailure(body);
    }

    @Test void rejectsInvalidNestedFieldUsingStableValidationError() throws Exception {
        String body=validRequest(UUID.randomUUID()).replace("\"title\":\"Two Sum\"", "\"title\":\"%s\"".formatted("a".repeat(201)));
        assertValidationFailure(body);
    }

    private void assertValidationFailure(String body) throws Exception {
        mvc.perform(post("/api/v1/questions").contentType(MediaType.APPLICATION_JSON).content(body))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.code").value("VALIDATION_ERROR"))
            .andExpect(jsonPath("$.message").value("Request validation failed"));
        Integer questionCount=jdbc.queryForObject("select count(*) from question.questions", Integer.class);
        Integer versionCount=jdbc.queryForObject("select count(*) from question.question_versions", Integer.class);
        org.assertj.core.api.Assertions.assertThat(questionCount).isZero();
        org.assertj.core.api.Assertions.assertThat(versionCount).isZero();
    }

    private static String validRequest(UUID ownerUserId) {
        return """
          {"ownerUserId":"%s","content":{"title":"Two Sum","prompt":"Find pair","constraintsText":"n >= 2","examples":[],"supportedLanguages":["java"],"visibleTests":[{"input":"[2,7]","output":"[0,1]"}],"hiddenTests":[{"input":"secret-input","output":"secret-output"}],"scoringRules":{"points":100},"executionLimits":{"timeMs":1000}}}
          """.formatted(ownerUserId);
    }
}
